package com.kitri.member.model;

public class ZipDto {
	private String zipcode;
	private String address; //sido||' '||gugun||' '||doro as address
	
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
